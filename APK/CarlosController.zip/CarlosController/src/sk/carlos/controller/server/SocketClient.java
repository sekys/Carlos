package sk.carlos.controller.server;

import java.io.*;
import java.net.Socket;

import sk.carlos.controller.settings.SettingsActivity;

import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.os.Message;
import android.util.Log;


public class SocketClient {

	private static final String TAG = "Controller - " + SocketClient.class.getSimpleName();
	
	private static Handler handler;	
	private static Handler uiHandler;
	private static HandlerThread handlerThread;
	
    private Listener listener = null;
    private Sender sender = null;
    public boolean connected = false;
    ServerResponses viewer = null;

    private static SocketClient CLIENT;
    
    public static SocketClient getInstance(){
		return CLIENT;
	}
	
	public static SocketClient createInstance(String ip, ServerResponses responseListener){
		uiHandler = new Handler();
        handlerThread = new HandlerThread("handlerThread");
        handlerThread.start();
//        handler = new HandlerExtension(handlerThread.getLooper());
		
		CLIENT = null;
		CLIENT = new SocketClient(ip, responseListener);
		return CLIENT;
	}

	private void finish(){
		try{
			handler.getLooper().quit();
			CLIENT = null;
		}catch(Exception e){
			Log.d(TAG, "exception by finishing thread ",e);
		}
	}
    
    class Listener extends Thread {
        Socket conn = null;
        boolean listening = true;

        public Listener(Socket conn) {
            this.conn = conn;
            this.setName("JavaClientSocketListener");
            this.start();
        }

        @Override public void run() {

            InputStream instream = null;

            try {
                BufferedReader reader =
                    new BufferedReader(new InputStreamReader(conn.getInputStream()));


                while ( listening ) {
                    String xml = reader.readLine();
                    if ( xml == null ) {
                        // Connection lost
                        return;
                    }

                    System.out.println("XML: " + xml + "\n\n");

                    // Hand off to the UI
                    if ( xml.indexOf("HostnameResponse") != -1 )
                        viewer.onHostnameResponse(xml);
                    else if ( xml.indexOf("MemoryResponse") != -1 )
                        viewer.onMemoryResponse(xml);
                    else if ( xml.indexOf("RandomNumberResponse") != -1 )
                        viewer.onRandomNumberResponse(xml);
                }
            }
            catch ( StreamCorruptedException sce) {
                // skip over the bad bytes
                try {
                    if ( instream != null )
                        instream.skip(instream.available());
                }
                catch ( Exception e1 ) {
                    listening = false;
                }
            }
            catch ( Exception e ) {
                e.printStackTrace();
                listening = false;
            }
        }
    }
    
    public void sendEvent(String event) {
    	Log.d(TAG, event);
    	sender.serializeAndSendMessage(event);
    }

    class Sender {
        static final String HOSTNAME = "<Request><Name>GetHostname</Name></Request>";
        static final String MEMORY = "<Request><Name>GetMemory</Name></Request>";
        static final String RANDOM_NUM = "<Request><Name>GetRandomNumber</Name></Request>";
        
        Socket conn;
        BufferedOutputStream os = null;

        public Sender(Socket conn) {
            try {
                this.conn = conn;
                this.conn.setTcpNoDelay(true);
                this.os = new BufferedOutputStream( conn.getOutputStream() );
            }
            catch ( Exception e ) {
                e.printStackTrace();
            }
        }

        public void requestHostname() {
            serializeAndSendMessage(HOSTNAME);
        }

        public void requestMemory() {
            serializeAndSendMessage(MEMORY);
        }

        public void requestRandomNumber() {
            serializeAndSendMessage(RANDOM_NUM);
        }

        private void serializeAndSendMessage(String msg) {
            try {
                os.write( msg.getBytes() );
                os.flush();
            }
            catch ( Exception e ) {
                e.printStackTrace();
            }
        }
    }

    public SocketClient(String IPAddress, ServerResponses viewer) {
        try {
            // Connect to the server at the given address on port 8080
            if ( IPAddress == null || IPAddress.length() == 0 )
                IPAddress = "10.0.2.2";
            Socket conn = new Socket(IPAddress, 8080 );
            conn.setTcpNoDelay(true);
            this.listener = new Listener(conn);
            this.sender = new Sender(conn);
            this.connected = true;
            this.viewer = viewer;
        }
        catch ( Exception e ) {
            connected = false;
            e.printStackTrace();
        }
    }

    public boolean isConnected() {
        return connected;
    }

    public void requestHostname() {
        sender.requestHostname();
    }

    public void requestMemory() {
        sender.requestMemory();
    }

    public void requestRandomNumber() {
        sender.requestRandomNumber();
    }

	public static void createInstance(String string,
			SettingsActivity settingsActivity) {
		// TODO Auto-generated method stub
		
	}
	
	private final class HandlerExtension extends Handler {
		private HandlerExtension(Looper looper) {
			super(looper);
		}

		@Override
		public void handleMessage(Message msg) {
			Log.d(TAG, "handle message");
			super.removeMessages(0);
		}
	}
}


