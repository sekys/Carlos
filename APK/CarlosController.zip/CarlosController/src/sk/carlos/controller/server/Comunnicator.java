package sk.carlos.controller.server;

import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.net.UnknownHostException;

import sk.carlos.controller.helper.PreferenceHelper;

import android.content.Context;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.os.Message;
import android.util.Log;

public class Comunnicator {

	private static final String TAG = "Controller - " + Comunnicator.class.getSimpleName();
    private  String IPADRESS = null; /** < ip adress of TCP server, where comunnicator connects*/
    private int SERVERPORT; /** < TCP server port*/

	private Handler handler;	
	private Handler uiHandler;
	private HandlerThread handlerThread;
	
	private String serverUrl;
	private String message;
	
	private boolean isLogged = false;	
	
	private String loginUrl;
	private String loggoutUrl;
	private String eventUrl;
	private String handleEventUrl;
	private String deviceId;
	private String deviceType;
	
	private static Comunnicator COMMUNICATOR;
	
	
	public static Comunnicator getInstance(){
		return COMMUNICATOR;
	}
	
	/**
	 * 
	 * @param ctx
	 * @return
	 * 
	 * method for create comunnicator singletone
	 * 
	 */
	public static Comunnicator createInstance(Context ctx){
		COMMUNICATOR = null;
		COMMUNICATOR = new Comunnicator(ctx);
		return COMMUNICATOR;
	}
	
	public static Comunnicator createInstance(Context ctx, OnServerResponseListener responseListener){
		COMMUNICATOR = null;
		COMMUNICATOR = new Comunnicator(ctx, responseListener);
		return COMMUNICATOR;
	}
	
	private Comunnicator(Context ctx, OnServerResponseListener responseListener) {
		this(ctx);
		this.responseListener = responseListener;		
	}
	
	private Comunnicator(Context ctx) {
		uiHandler = new Handler();
        handlerThread = new HandlerThread(getClass().getSimpleName());
        handlerThread.start();
        handler = new HandlerExtension(handlerThread.getLooper());
	}
	
	/**
	 * 
	 * @param msg
	 * @throws IOException
	 * 
	 * method for sending string message to TCP server
	 */
	
	public void send(final String msg) throws IOException{
		String ipAndPort = PreferenceHelper.getServerIPADRESS();
		String[] parts = ipAndPort.split(":");
		String part1 = parts[0] + ":" + parts[1]; // ipaddress
		String part2 = parts[2]; // port
		String[] numberParts = part2.split("\n");
		
		IPADRESS = part1.substring(part1.lastIndexOf("/") + 1);
		SERVERPORT = Integer.parseInt(numberParts[0]);
		
		Log.d(TAG, "IPADRESA je: "+ IPADRESS);
		Log.d(TAG, "PORT je: "+ SERVERPORT);

		
		Log.d(TAG, "posielam socket: "+ msg);
		String url = IPADRESS;
		Log.d(TAG, "URL-ka: " + url);
		
		Thread thread = new Thread(new Runnable(){
		    @Override
		    public void run() {
		        try {
		        	Socket socket = null;
		   		 DataOutputStream dos = null;

		   		 try {
		   			 socket = new Socket(IPADRESS, SERVERPORT);
		   			 dos = new DataOutputStream(socket.getOutputStream());
		   			 dos.writeBytes(msg);
		   		 } catch (UnknownHostException e) {
		   			 // TODO Auto-generated catch block
		   			 e.printStackTrace();
		   		 } catch (IOException e) {
		   			 // TODO Auto-generated catch block
		   			 e.printStackTrace();
		   		 }
		   		 finally{
		   			 if (socket != null){
		   				 try {
		   					 socket.close();
		   				 } catch (IOException e) {
		   					 // TODO Auto-generated catch block
		   					 e.printStackTrace();
		   				 }
		   			 }

		   			 if (dos != null){
		   				 try {
		   					 dos.close();
		   				 } catch (IOException e) {
		   					 // TODO Auto-generated catch block
		   					 e.printStackTrace();
		   				 }
		   			 }

		   			 if (dos != null){
		   				 try {
		   					 dos.close();
		   				 } catch (IOException e) {
		   					 // TODO Auto-generated catch block
		   					 e.printStackTrace();
		   				 }
		   			 }
		   		 }		
		        } catch (Exception e) {
		        	e.printStackTrace();
		        }
		    }
		});

		thread.start();	

		

	}

	
	
	

	public static interface OnServerResponseListener{
		public abstract void onServerResponse(int statusCode, String response);
	} 
	
	private OnServerResponseListener responseListener;
	
	public void registerOnServerResponseListener(OnServerResponseListener listener){
		this.responseListener = listener;
	}
	
	public void unregisterOnServerResponseListener(){
		this.responseListener = null;
	}
	
	private final class HandlerExtension extends Handler {
		private HandlerExtension(Looper looper) {
			super(looper);
		}

		@Override
		public void handleMessage(Message msg) {
			Log.d(TAG, "handle message");
			super.removeMessages(0);
		}
	}


}
