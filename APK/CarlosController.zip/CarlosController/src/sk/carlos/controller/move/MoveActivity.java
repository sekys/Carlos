package sk.carlos.controller.move;

import java.io.IOException;

import sk.carlos.controller.R;
import sk.carlos.controller.server.Comunnicator;
import sk.carlos.controller.server.ServerResponses;
import sk.carlos.controller.server.SocketClient;

import android.app.Activity;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

public class MoveActivity extends Activity implements SensorEventListener, ServerResponses {

	private static final String TAG = "Controller - " + MoveActivity.class.getSimpleName();

	private static final int SENSOR_THRESHOLD = 5;
	private static final int TIME_THRESHOLD = 400 * 1000 * 1000 *1000;

	private SensorManager mSensorManager;
	private Sensor mAccelerometer;

	private Comunnicator communicator;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.move_activity_layout);
		getActionBar().setIcon(R.drawable.ic_bulb);
		getActionBar().setBackgroundDrawable(getResources().getDrawable(R.drawable.action_bar_bg));
		try {
			if (communicator.getInstance() == null)
				communicator = communicator.createInstance(this);
			else
				communicator = communicator.getInstance();
		} catch (NullPointerException e) {
			Log.d(TAG, "exception by creating server communication instance ",e);
		}

		mSensorManager = (SensorManager)getSystemService(SENSOR_SERVICE);
		mAccelerometer = mSensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
	}

	protected void onResume() {
		super.onResume();
		mSensorManager.registerListener(this, mAccelerometer, SensorManager.SENSOR_DELAY_NORMAL);
	}

	protected void onPause() {
		super.onPause();
		mSensorManager.unregisterListener(this);
	}

	@Override
	public void onAccuracyChanged(Sensor sensor, int accuracy) {
		// TODO Auto-generated method stub

	}

	private long timestamp = 0;

	@Override
	public void onSensorChanged(SensorEvent event) {
		if (event.sensor.getType() == Sensor.TYPE_ACCELEROMETER){

			//Log.d(TAG, "x: "+ event.values[0]);
			//Log.d(TAG, "y: "+ event.values[1]);
			//Log.d(TAG, "z: "+ event.values[2]);
			float x = event.values[0], y = event.values[1];
			//Log.d(TAG, "evet timestamp: "+ event.timestamp);

			if((Math.abs(x) > SENSOR_THRESHOLD || Math.abs(y) > SENSOR_THRESHOLD) && (event.timestamp - timestamp) > TIME_THRESHOLD){
				timestamp = event.timestamp;
				if(Math.abs(x) > SENSOR_THRESHOLD){
					if(x < 0){
						Log.d(TAG, "move left");
						Toast.makeText(getApplicationContext(), "left", Toast.LENGTH_SHORT).show();
						Log.d(TAG, "send event: left");
//						String eventString = "left";
						String eventString = "Command:a";

						try {
							communicator.send(eventString);
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}				
						return;
					}else{
						Log.d(TAG, "move right");
						Toast.makeText(getApplicationContext(), "right", Toast.LENGTH_SHORT).show();
						Log.d(TAG, "send event: right");
//						String eventString = "right";
						String eventString = "Command:d";

						try {
							communicator.send(eventString);
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						return;
					}

				}else if(Math.abs(y) > SENSOR_THRESHOLD){
					if(y < 0){
						Log.d(TAG, "move down");
						Toast.makeText(getApplicationContext(), "down", Toast.LENGTH_SHORT).show();
						Log.d(TAG, "send event: down");
//						String eventString = "down";
						String eventString = "Command:s";

						try {
							communicator.send(eventString);
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						return;
					}else{
						Log.d(TAG, "move top");
						Toast.makeText(getApplicationContext(), "top", Toast.LENGTH_SHORT).show();
						Log.d(TAG, "send event: top");
//						String eventString = "top";
						String eventString = "Command:w";

						try {
							communicator.send(eventString);
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						return;
					}

				}
			}				 
		}

	}

	@Override
	public void onHostnameResponse(String msg) {
		// TODO Auto-generated method stub

	}

	@Override
	public void onMemoryResponse(String msg) {
		// TODO Auto-generated method stub

	}

	@Override
	public void onRandomNumberResponse(String msg) {
		// TODO Auto-generated method stub

	}
}
