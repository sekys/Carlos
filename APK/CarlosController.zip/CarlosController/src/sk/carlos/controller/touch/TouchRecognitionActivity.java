package sk.carlos.controller.touch;

import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.net.UnknownHostException;

import sk.carlos.controller.R;
import sk.carlos.controller.helper.*;
import sk.carlos.controller.touch.ContinuousGestureDetector.ContinuousGestureListener;
import sk.carlos.controller.server.*;
import sk.carlos.controller.settings.WebSettingsActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

public class TouchRecognitionActivity extends Activity implements ContinuousGestureListener, ServerResponses {
	
	private static final String TAG = "Controller - " + TouchRecognitionActivity.class.getSimpleName();
	
	private View control;
	
	private ContinuousGestureDetector detector;
	private Comunnicator communicator;
    
    private SocketClient client = null;

	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        control = findViewById(R.id.controll_layout);
        getActionBar().setIcon(R.drawable.ic_bulb);
        getActionBar().setBackgroundDrawable(getResources().getDrawable(R.drawable.action_bar_bg));
        
        try {
			if (communicator.getInstance() == null)
				communicator = communicator.createInstance(this);
			else
				communicator = communicator.getInstance();
		} catch (NullPointerException e) {
			Log.d(TAG, "exception by creating server communication instance ",e);
		}
        
        /*
        try {
        	if (SocketClient.getInstance() == null)
        		client = SocketClient.createInstance(IPADRESS, this);
        	else
        		client = SocketClient.getInstance();
        } catch (NullPointerException e) {
        	Log.d(TAG, "exception by creating server communication instance ",e);
        }
        
        if ( client.isConnected() ) {
            String msg = "Connected to server " +  IPADRESS;
            Log.d(TAG, msg);
            
        }
        else {
            String msg = "Failed to connect to server " +  IPADRESS;
            Log.d(TAG, msg);
        }
        
        */
        
		detector = new ContinuousGestureDetector();
		control.setOnTouchListener(detector);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.activity_main, menu);
        return true;
    }    
    
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
    	Intent intent;
    	switch (item.getItemId()) {
		case R.id.web_settings:
			intent = new Intent(this, WebSettingsActivity.class);
			startActivity(intent);
			break;
		case R.id.touch_add:
			
			break;
		}
    	return true;
    }
	
	@Override
	protected void onResume() {
		detector.setContinuousGestureListener(this);
//		communicator.registerOnServerResponseListener(this);
		super.onResume();
	}
	
	@Override
	protected void onPause() {
		detector.setContinuousGestureListener(null);
//		communicator.unregisterOnServerResponseListener();
		super.onPause();
	}

	/**
	 * methods for sending each of touch events
	 */
	
	@Override
	public void onRightSwipe() {
		Log.d(TAG, "send event: RightSwipe - D");
		String event = "Command:d";
		try {
			communicator.send(event);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
//		if(client.getInstance() != null)
//			client.sendEvent(event);
		
	}

	@Override
	public void onLeftSwipe() {
		Log.d(TAG, "send event: LeftSwipe - A");
		String event = "Command:a";
		try {
			communicator.send(event);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
	}

	@Override
	public void onTopSwipe() {
		Log.d(TAG, "send event: TopSwipe - W");
		String event = "Command:w";
		try {
			communicator.send(event);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public void onBottomSwipe() {
		Log.d(TAG, "send event: BottomSwipe - S");
		String event = "Command:s";
		try {
			communicator.send(event);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public void onTap() {
		Log.d(TAG, "send event: Tap - W");
		String event = "Command:r";
		try {
			communicator.send(event);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	

	@Override
	public void onHostnameResponse(String msg) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onMemoryResponse(String msg) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onRandomNumberResponse(String msg) {
		// TODO Auto-generated method stub
		
	}

	
//	@Override
//	public void onServerResponse(int responseCode, String response) {
//		if (!CommunicationHelper.isOK(responseCode)) 
//			Toast.makeText(this, getString(R.string.error_event_not_sent), Toast.LENGTH_LONG).show();		
//	}
}
