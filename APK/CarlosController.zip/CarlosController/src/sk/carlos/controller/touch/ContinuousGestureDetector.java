package sk.carlos.controller.touch;

import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;

public class ContinuousGestureDetector implements OnTouchListener{
	
	private static final int DEFAULT_CLICK_TIME = 100;
	private static final int DEFAULT_DISTANCE = 100;
	
	private ContinuousGestureListener listener = null;
	
	private long start;
	private float x1, y1;
	private int distance, clickTime;
	
	public ContinuousGestureDetector(int minDistance, int minClickTime) {
		this.distance = minDistance;
		this.clickTime = minClickTime;
	}
	
	public ContinuousGestureDetector(int minDistance) {
		this.distance = minDistance;
		this.clickTime = DEFAULT_CLICK_TIME;
	}
	
	public ContinuousGestureDetector() {
		this.distance = DEFAULT_DISTANCE;
		this.clickTime = DEFAULT_CLICK_TIME;
	}
	
	public void setContinuousGestureListener(ContinuousGestureListener listener){
		this.listener = listener;
	}

	@Override
	public boolean onTouch(View v, MotionEvent event) {
		if(event.getAction() == MotionEvent.ACTION_DOWN){
			start = System.currentTimeMillis();
			x1 = event.getX();y1 = event.getY();
		}else if(event.getAction() == MotionEvent.ACTION_UP){
			if(((System.currentTimeMillis() - start) < clickTime) && (this.listener != null)) {
				listener.onTap();
			}else detectGesture(this.x1, this.y1, event.getX(), event.getY());
		}else if(event.getAction() == MotionEvent.ACTION_MOVE){
			if(detectGesture(this.x1, this.y1, event.getX(), event.getY())){
				x1 = event.getX();y1 = event.getY();
			}
		}
		return true;
	}
	
	private boolean detectGesture(float x1,float y1,float x2,float y2){
		if(Math.abs(x1 - x2) > distance){
			if((x1 < x2) && (this.listener != null)){
				this.listener.onRightSwipe();
				return true;
			}				
			else if((x1 > x2) && (this.listener != null)){
				this.listener.onLeftSwipe();
				return true;
			}			
		}
		if(Math.abs(y1 - y2) > distance){
			if((y1 < y2) && (this.listener != null)){
				listener.onBottomSwipe();
				return true;
			}			
			else if((y1 > y2) && (this.listener != null)){
				listener.onTopSwipe();
				return true;
			}				
		}
		return false;
	}
	
	public static interface ContinuousGestureListener{
		public abstract void onRightSwipe();
		public abstract void onLeftSwipe();
		public abstract void onTopSwipe();
		public abstract void onBottomSwipe();	
		public abstract void onTap();
	}
}
