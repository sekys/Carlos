package sk.carlos.controller.turist;

import java.io.IOException;

import sk.carlos.controller.R;
import sk.carlos.controller.extra.extraActivity;
import sk.carlos.controller.server.Comunnicator;
import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class TuristActivity extends Activity implements OnClickListener{

	private static final String TAG = "Controller - " + TuristActivity.class.getSimpleName();

	
	private Comunnicator communicator;
	
	private Button button_whatisthat;
	private Button button_saymore;	
	
	
	
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.turist_activity_layout);
		getActionBar().setIcon(R.drawable.ic_bulb);
		getActionBar().setBackgroundDrawable(getResources().getDrawable(R.drawable.action_bar_bg));

		try {
			if (communicator.getInstance() == null)
				communicator = communicator.createInstance(this);
			else
				communicator = communicator.getInstance();
		} catch (NullPointerException e) {
			Log.d(TAG, "exception by creating server communication instance ",e);
		}
		
		button_whatisthat = (Button) findViewById(R.id.button_whatisthat);
		button_saymore = (Button) findViewById(R.id.button_saymore);
		
		button_whatisthat.setOnClickListener(this);
		button_saymore.setOnClickListener(this);
		
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		String msg = "null";
		switch (v.getId()) {
		case R.id.button_whatisthat:
			msg = "Command:t";
			break;
		case R.id.button_saymore:
			msg = "Command:y";
			break;
		default:
			break;
		}
		try {
			Log.d(TAG, "Send event: " + msg);
			communicator.send(msg);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	@Override
	protected void onPause() {
		// TODO Auto-generated method stub
		super.onPause();
	}

	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
	}
}
