package sk.carlos.controller;

import java.io.IOException;

import sk.carlos.controller.helper.*;
import sk.carlos.controller.move.MoveActivity;
import sk.carlos.controller.extra.extraActivity;
import sk.carlos.controller.gestures.*;
import sk.carlos.controller.gps.gpsLoggerActivity;
import sk.carlos.controller.server.Comunnicator;
import sk.carlos.controller.settings.SettingsActivity;
import sk.carlos.controller.touch.TouchRecognitionActivity;
import sk.carlos.controller.turist.TuristActivity;
import sk.carlos.controller.voice.VoiceRecognitionActivity;
import sk.carlos.controller.settings.*;

import sk.carlos.controller.R;
import android.app.Activity;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageButton;
import android.widget.Switch;

public class StartActivity extends Activity implements OnClickListener, android.view.View.OnClickListener {

private static final String TAG = "Controller - " + StartActivity.class.getSimpleName();
	

	private Comunnicator communicator;

	private ImageButton touch;
	private ImageButton voice;
	private ImageButton gesture;
	private ImageButton move;
	private ImageButton gps;
	private ImageButton extra;
	private ImageButton turist;
	private ImageButton game;
	private ImageButton tourist;
	
	private boolean canPress = true;
	

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.d(TAG, "onCreate");
        setContentView(R.layout.start_activity_layout);
        getActionBar().setIcon(R.drawable.ic_bulb);
        getActionBar().setBackgroundDrawable(getResources().getDrawable(R.drawable.action_bar_bg));
        
		try {
			if (communicator.getInstance() == null)
				communicator = communicator.createInstance(this);
			else
				communicator = communicator.getInstance();
		} catch (NullPointerException e) {
			Log.d(TAG, "exception by creating server communication instance ",e);
		}

        
        touch = (ImageButton) findViewById(R.id.StartActivity_buttonTouch);
        voice = (ImageButton) findViewById(R.id.StartActivity_buttonVoice);
        gesture  = (ImageButton) findViewById(R.id.StartActivity_buttonGesture);
        move  = (ImageButton) findViewById(R.id.StartActivity_buttonMove);
        gps = (ImageButton) findViewById(R.id.StartActivity_buttonGPS);
//        extra = (ImageButton) findViewById(R.id.StartActivity_buttonExtra);
        turist = (ImageButton) findViewById(R.id.StartActivity_buttonTurist);
        game = (ImageButton) findViewById(R.id.StartActivity_buttonGame);
        tourist = (ImageButton) findViewById(R.id.StartActivity_buttonTourist);
        
        touch.setOnClickListener(this);
        voice.setOnClickListener(this);
        gesture.setOnClickListener(this);
        move.setOnClickListener(this);
        gps.setOnClickListener(this);
//        extra.setOnClickListener(this);
        turist.setOnClickListener(this);
        game.setOnClickListener(this);
        tourist.setOnClickListener(this);
        
        
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.activity_start, menu);
        return true;
    }    
    
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
    	Intent intent;
    	switch (item.getItemId()) {
		case R.id.menu_settings:
			intent = new Intent(this, SettingsActivity.class);
			startActivity(intent);
			break;
		default:
			break;
		}
    	return true;
    }
	
	@Override
	public void onBackPressed() {
		NotificationHelper.createDecisionDialog(this, R.string.finish_dialog_title, R.string.finish_dialog_message, R.string.finish_dialog_yes, this, R.string.finish_dialog_no, NotificationHelper.getDefaultNegativeListener()).show();
	}

	@Override
	public void onClick(DialogInterface dialog, int which) {
		FileHelper.finish();
		super.onBackPressed();		
	}
	
	@Override
	public void onClick(View v) {
		
		if( ! StringHelper.isIPCorrect(PreferenceHelper.getServerIp(this))){
			NotificationHelper.createDecisionDialog(this, R.string.dialog_incorrect_ip_title, R.string.dialog_incorrect_ip_message, R.string.finish_dialog_yes, new OnClickListener() {
				
				@Override
				public void onClick(DialogInterface dialog, int which) {
					Intent intent = new Intent(StartActivity.this, SettingsActivity.class);
					startActivity(intent);					
				}
			}, R.string.finish_dialog_no, NotificationHelper.getDefaultNegativeListener()).show();
			return;
		/*}
		else if (!ServerCommunicator.getInstance().isLogged()) {
			NotificationHelper.createSimplyDialog(this, R.string.dialog_not_connected_title, R.string.dialog_not_connected_message).show();*/
		} else{
			Class<?> c = null;
			
			/**
			 *  switch for main activities - gestures, move, voice, touch, gps and extra
			 */
			
			switch (v.getId()) {
			case R.id.StartActivity_buttonGesture:
//				c = GestureRecognizerActivity.class;
				break;
			case R.id.StartActivity_buttonMove:
				c = MoveActivity.class;
				break;
			case R.id.StartActivity_buttonVoice:
				c = VoiceRecognitionActivity.class;
				break;
			case R.id.StartActivity_buttonTouch:
				c = TouchRecognitionActivity.class;
				break;
			case R.id.StartActivity_buttonGPS:
				c = gpsLoggerActivity.class;
				break;
//			case R.id.StartActivity_buttonExtra:
//				c = extraActivity.class;
//				break;
			case R.id.StartActivity_buttonTurist:
				c = TuristActivity.class;
				break;
			case R.id.StartActivity_buttonGame:
				runGame();
				break;
			case R.id.StartActivity_buttonTourist:
				runTourist();
				break;
			case R.id.web_settings:
				c = WebSettingsActivity.class;
			}
			
			if(c != null) {
				Intent act = new Intent(this, c);
				startActivity(act);
			}
		} 
	}
	
	
	
	void runGame() {
		Log.d(TAG, "Run Game");
		String msg = null;
			try {
				msg = "Command:u";
				Log.d(TAG, "Send event: " + msg);
				communicator.send(msg);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	}
	
	void runTourist() {
		Log.d(TAG, "Run Tourist");
		String msg = null;
			try {
				msg = "Command:i";
				Log.d(TAG, "Send event: " + msg);
				communicator.send(msg);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	}
	
}
