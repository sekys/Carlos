package sk.carlos.controller.helper;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import android.content.Context;
import android.provider.Settings.Secure;
import android.util.Log;

public class StringHelper {
	
	private static final String TAG = "Controller - " + StringHelper.class.getSimpleName();
	
	public static String getDeviceID(Context ctx){
		return "Android_" + Secure.getString(ctx.getContentResolver(), Secure.ANDROID_ID);
	}
	
	public static String getServerUrl(Context ctx){
		String ip = PreferenceHelper.getServerIp(ctx);
		if(!ip.endsWith("/"))
			ip += "/";
		return ip;
	}
	
	public static String getServerUrl(Context ctx, String appendix){
		String ip = PreferenceHelper.getServerIp(ctx);
		if(!ip.endsWith("/"))
			ip += "/";
		ip += appendix;
		return ip;
	}
	
	public static String getServerUrl(Context ctx, int stringResource){
		String ip = PreferenceHelper.getServerIp(ctx);
		if(!ip.endsWith("/"))
			ip += "/";
		ip += ctx.getString(stringResource);
		return ip;
	}

	public static String normalizeVoiceResult(ArrayList<String> matches) {
		StringBuilder builder = new StringBuilder();
		for(String s : matches){
			builder = builder.append(s).append("_");
		}
		builder = builder.deleteCharAt(builder.length()-1);
		String result = builder.toString();
		if(result.contains(" ")) result = result.replaceAll(" ", "");
		return result;
	}
	
	public static boolean isIPCorrect(String s){
		return s.matches("^http:\\/\\/.+:[0-9]+$");
	}
	
	//regOn
	//handleEvent post detected
	//event -post new 
	//event/rukaHore -put edit,  -delete remove  -get info
	//regOff 
	
	public static String removeDiacriticalMarks(String string) {
		/*if (Build.VERSION.SDK_INT < 9)
			return AsciiUtils.convertNonAscii(string);*/
		try {
			Class<?> normalizerClass = Class.forName("java.text.Normalizer");
			Class<?> formEnum = Class.forName("java.text.Normalizer$Form");
			Field formEnumField = formEnum.getField("NFD");
			
			Method normalizeMethod = normalizerClass.getDeclaredMethod("normalize", java.lang.CharSequence.class, formEnum);
			return ((String)normalizeMethod.invoke(null, string, formEnumField.get(null))).replaceAll("\\p{InCombiningDiacriticalMarks}+", "");
//			return java.text.normalize(string, java.text.Normalizer.Form.NFD).replaceAll("\\p{InCombiningDiacriticalMarks}+", "");
		} catch (Exception e1) {
//			throw new RuntimeException(e1);
//			return convertNonAscii(string);
		}
		
		//temporary return NULL
		return null;
	}
	
}
