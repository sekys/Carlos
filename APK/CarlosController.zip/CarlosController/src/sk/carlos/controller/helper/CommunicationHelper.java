package sk.carlos.controller.helper;

public class CommunicationHelper {
	
	public static boolean isOK(int responseCode){
		return  responseCode == 200;
	}

}
