package sk.carlos.controller.helper;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;

public class NotificationHelper {

	public static AlertDialog createDecisionDialog(Context context, int title_res, int message_res, 
			int positive_res, OnClickListener positive, int negative_res, OnClickListener negative) {
		return createDecisionDialog(context, context.getString(title_res), context.getString(message_res), positive_res, positive, negative_res, negative);
	}
	
	public static AlertDialog createDecisionDialog(Context context, String title, String message, 
			int positive_res, OnClickListener positive, int negative_res, OnClickListener negative) {
		AlertDialog.Builder builder = new AlertDialog.Builder(context);
		builder.setCancelable(false).setTitle(title).setMessage(message);
		builder.setPositiveButton(positive_res, positive);
		builder.setNegativeButton(negative_res, negative);
		return builder.create();
	}
	
	public static AlertDialog createSimplyDialog(Context context, int title_res, int message_res) {
		AlertDialog.Builder builder = new AlertDialog.Builder(context);
		builder.setCancelable(false).setTitle(title_res).setMessage(message_res);
		builder.setPositiveButton("OK", new OnClickListener() {
			
			@Override
			public void onClick(DialogInterface dialog, int which) {
				dialog.dismiss();
			}
		});
		return builder.create();
	}
	
	public static OnClickListener getDefaultNegativeListener(){
		return new OnClickListener() {
			
			@Override
			public void onClick(DialogInterface dialog, int which) {
				dialog.dismiss();
			}
		};
	}
}
