package sk.carlos.controller.helper;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;

import android.gesture.Gesture;
import android.gesture.GestureLibraries;
import android.gesture.GestureLibrary;
import android.gesture.GestureStore;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Environment;
import android.util.Base64;

public class FileHelper {
	
	private static final String GESTURES_FILE_NAME = "gestures";
	private static final String VOICES_FILE_NAME = "voices";
	private static final String DIRECTORY_NAME = "teamtoo";
	
	private static File GESTURE_FILE = null;
	private static GestureLibrary LIBRARY;
	
	public static void finish(){
		GESTURE_FILE = null;
		LIBRARY = null;
	}
	
	public static File getDefaultVoices() throws IOException{
		File voices = new File(checkDirectory(), VOICES_FILE_NAME);
		if(!voices.exists())
			voices.createNewFile();
		return voices;
	}
	
	public static File getGestures(){
		if(GESTURE_FILE == null)
			GESTURE_FILE = new File(checkDirectory(), GESTURES_FILE_NAME); 
		return GESTURE_FILE;
	}
	
	private static File checkDirectory(){
		File directory = new File(Environment.getExternalStorageDirectory(), DIRECTORY_NAME + "/");
		if(!directory.exists()) 
			directory.mkdirs();
		return directory;
	}
	
	public static void addGesture(Gesture g, String name){
		if(LIBRARY == null){
			getGestureLibrary();
		}
		LIBRARY.addGesture(name, g);
		LIBRARY.save();		
	}
	
	public static GestureLibrary getGestureLibrary(){
		if(LIBRARY == null){
			LIBRARY = GestureLibraries.fromFile(FileHelper.getGestures()); 
			LIBRARY.setOrientationStyle(GestureStore.ORIENTATION_SENSITIVE);
			LIBRARY.setSequenceType(GestureStore.SEQUENCE_SENSITIVE);
		}
		return LIBRARY;
	}
	
	public static String bitmapToString(Bitmap b){
		ByteArrayOutputStream baos = new ByteArrayOutputStream();  
	    b.compress(Bitmap.CompressFormat.PNG, 100, baos);
	    byte[] bytes = baos.toByteArray();
	    return "data:image/png;base64," + Base64.encodeToString(bytes,Base64.DEFAULT);
	}
	
	public static Bitmap stringToBitmap(String base){
		byte[] decodedByte = Base64.decode(base, 0);
	    return BitmapFactory.decodeByteArray(decodedByte, 0, decodedByte.length);
	}

	public static void removeGesture(String name, Gesture g) {
		if(LIBRARY == null) getGestureLibrary();
		LIBRARY.removeGesture(name,	g);
		LIBRARY.save();		
	}
}
