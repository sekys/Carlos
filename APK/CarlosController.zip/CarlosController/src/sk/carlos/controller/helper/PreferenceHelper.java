package sk.carlos.controller.helper;


import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Environment;
import android.util.Log;

public class PreferenceHelper {
	
	public static final String SHARED_PREFERENCES_ID = "androidControllerPreferences";
	public static final String KEY_IP_SERVER = "songActuallyPlaying";
	
	public static synchronized void setServerIp(Context ctx, String ip){
		SharedPreferences prefs = ctx.getSharedPreferences(SHARED_PREFERENCES_ID, Context.MODE_PRIVATE);
		SharedPreferences.Editor editor = prefs.edit();
		editor.putString(KEY_IP_SERVER, ip);
		editor.commit();
	}	
	
	public static synchronized String getServerIp(Context ctx){
		SharedPreferences prefs = ctx.getSharedPreferences(SHARED_PREFERENCES_ID, Context.MODE_PRIVATE);
		return prefs.getString(KEY_IP_SERVER, "");
	}
	
	public static String getServerIPADRESS () {
		String ipadress = null;
		
		String root = Environment.getExternalStorageDirectory().toString();
		//Get the text file
		File file = new File(root,"ipaddress.txt");

		//Read text from file
		StringBuilder text = new StringBuilder();

		try {
		    BufferedReader br = new BufferedReader(new FileReader(file));
		    String line;

		    while ((line = br.readLine()) != null) {
		        text.append(line);
		        text.append('\n');
		    }
		}
		catch (IOException e) {
		    //You'll need to add proper error handling here
		}

		Log.d("Preferences", "IPAdress: " + text.toString());
		ipadress = text.toString();
		return ipadress;
	}

	private static InputStream openFileInput(String string) {
		// TODO Auto-generated method stub
		return null;
	}
}
