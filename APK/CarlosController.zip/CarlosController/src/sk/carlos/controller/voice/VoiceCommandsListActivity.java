package sk.carlos.controller.voice;


import java.io.IOException;
import java.util.List;

import sk.carlos.controller.R;
import sk.carlos.controller.helper.*;
import sk.carlos.controller.server.*;
import sk.carlos.controller.server.Comunnicator.OnServerResponseListener;
import sk.carlos.controller.voice.*;

import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnLongClickListener;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemLongClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

public class VoiceCommandsListActivity extends Activity implements OnServerResponseListener, OnClickListener, OnItemLongClickListener, DialogInterface.OnClickListener{

	private Comunnicator communicator;
	
	private EditText voiceAdd;
	private Button add;
	private ListView list;
	private CommandAdapter adapter;

	private String choosen = null;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.voice_command_list_activity_layout);
		getActionBar().setIcon(R.drawable.ic_bulb);
        getActionBar().setBackgroundDrawable(getResources().getDrawable(R.drawable.action_bar_bg));
        voiceAdd = (EditText) findViewById(R.id.voice_command_setter);
        list = (ListView) findViewById(android.R.id.list);
        add = (Button) findViewById(R.id.add_voice_command_button);
        add.setOnClickListener(this);
        Data.loadVoices();
        adapter = new CommandAdapter(this, R.layout.voice_command_item, Data.getVoices());
        list.setAdapter(adapter);
        communicator = Comunnicator.getInstance();
        list.setOnItemLongClickListener(this);
	}
	
	@Override
	protected void onResume() {
		communicator.registerOnServerResponseListener(this);
		super.onResume();
	}
	
	@Override
	protected void onPause() {
		communicator.unregisterOnServerResponseListener();
		super.onPause();
	}
	
	private class CommandAdapter extends ArrayAdapter<String>{

		private LayoutInflater mInflater;
		
		public CommandAdapter(Context context, int textViewResourceId, List<String> objects) {
			super(context, 0);
			mInflater = (LayoutInflater) context
					.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		}	
		
		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			if (convertView == null) {
				convertView = mInflater.inflate(R.layout.voice_command_item, parent, false);
			}
			final String command = getItem(position);
			final TextView label = (TextView) convertView;

			label.setTag(command);
			label.setText(command);
			
			return convertView;
		}
		
		@Override
		public int getCount() {
			return Data.getVoicesCount();
		}
		
		@Override
		public String getItem(int position) {
			return Data.getVoices().get(position);
		}
	}
	
	@Override
	public void onServerResponse(int statusCode, String response) {
		if(choosen != null){
			if(CommunicationHelper.isOK(statusCode)){
				Data.removeVoice(choosen);
				adapter.notifyDataSetChanged();
				NotificationHelper.createSimplyDialog(this, R.string.dialog_voice_command_list_deleted_title, R.string.dialog_voice_command_list_deleted_message);
			}else{
				NotificationHelper.createSimplyDialog(this, R.string.dialog_voice_command_list_not_deleted_title, R.string.dialog_voice_command_list_not_deleted_message);
			}
			choosen = null;
		}else if (CommunicationHelper.isOK(statusCode)) {
			Data.addVoice(StringHelper.removeDiacriticalMarks(voiceAdd.getText().toString()));
			adapter.notifyDataSetChanged();
			voiceAdd.setText("");
		} else {
			Toast.makeText(this, response, Toast.LENGTH_LONG).show();
		}
	}

	@Override
	public void onClick(View arg0) {
		if(voiceAdd.getText().toString() != null && voiceAdd.getText().toString().length() > 0){
			try {
				communicator.send((voiceAdd.getText().toString()));
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}		
	}

	@Override
	public boolean onItemLongClick(AdapterView<?> list, View v, int position,
			long id) {
		choosen = adapter.getItem(position);
		NotificationHelper.createDecisionDialog(this, getString(R.string.dialog_voice_command_list_delete_title), getString(R.string.dialog_voice_command_list_delete_message, choosen), R.string.finish_dialog_yes, this, R.string.finish_dialog_no, NotificationHelper.getDefaultNegativeListener());
		return true;
	}

	@Override
	public void onClick(DialogInterface dialog, int which) {
//		communicator.deleteEvent(choosen);		
	}
}

