package sk.carlos.controller.voice;


import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import sk.carlos.controller.R;
import sk.carlos.controller.helper.StringHelper;
import sk.carlos.controller.server.*;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.location.Address;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

public class VoiceRecognitionActivity extends Activity implements
		OnClickListener {

	private static List<String> VOICES = null;
	
	
	private static final String TAG = "Controller - " + VoiceRecognitionActivity.class.getSimpleName();
	private static final int VOICE_REQUEST_CODE = 25823;

	private TextView recognitionSupported;
	private TextView recognitionUnsupported;
	
	private ImageButton startRecognition;
	private ImageButton info;
	private ImageButton cloud;
	
	private Comunnicator communicator;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.voice_recognition_activity_layout);
		recognitionSupported = (TextView) findViewById(R.id.voice_recognition_supported);
		recognitionUnsupported = (TextView) findViewById(R.id.voice_recognition_not_supported);
		checkRecognitionAvailibility();
		getActionBar().setIcon(R.drawable.ic_bulb);
        getActionBar().setBackgroundDrawable(getResources().getDrawable(R.drawable.action_bar_bg));
        startRecognition = (ImageButton) findViewById(R.id.VoiceRecognition_buttonStart);
        startRecognition.setOnClickListener(this);
        info = (ImageButton) findViewById(R.id.VoiceRecognition_buttonInfo);
        info.setOnClickListener(this);
        cloud = (ImageButton) findViewById(R.id.VoiceRecognition_buttonCloud);
		findViewById(R.id.voice_recognition_content_view).setOnClickListener(this);
				
		try {
			if (communicator.getInstance() == null)
				communicator = communicator.createInstance(this);
			else
				communicator = communicator.getInstance();
		} catch (NullPointerException e) {
			Log.d(TAG, "exception by creating server communication instance ",e);

		}
		
		String msg = "Podporovane prikazy: Co je to?\nCo to je?\nPovedz mi viac.\nViac.";
		Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();

	}

	private static void addStringsToList() {
		VOICES = new ArrayList<String>();
		
		VOICES.add("cojeto");
		VOICES.add("cotoje");
		VOICES.add("povedzmiviac");
		VOICES.add("viac");
		
	}
	
	private void checkRecognitionAvailibility() {
		PackageManager pm = getPackageManager();
		List<ResolveInfo> activities = pm.queryIntentActivities(new Intent(
				RecognizerIntent.ACTION_RECOGNIZE_SPEECH), 0);
		if (activities.size() > 0) {
			recognitionSupported.setVisibility(View.VISIBLE);
		} else
			recognitionUnsupported.setVisibility(View.VISIBLE);
	}

	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.VoiceRecognition_buttonStart:
			Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
			intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
			intent.putExtra(RecognizerIntent.EXTRA_PROMPT,"Say your commands");
			intent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1);
			intent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
			intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "sk-SK");//sk-SK   en-EN
			startActivityForResult(intent, VOICE_REQUEST_CODE);
			return;
		case R.id.VoiceRecognition_buttonInfo:
			if(cloud.getVisibility() == View.GONE)
				cloud.setVisibility(View.VISIBLE);
			else 
				cloud.setVisibility(View.GONE);
			return;
		}
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);
		if (requestCode == VOICE_REQUEST_CODE && resultCode == RESULT_OK) {
			ArrayList<String> matches = data
					.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
			String s = StringHelper.normalizeVoiceResult(matches);
			s = StringHelper.removeDiacriticalMarks(s);
//			Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
			
			
//			if(Data.containsVoiceComand(s)){
			
				
			if(containsVoiceComand(s)) {
				Log.d(TAG, "send voice " + s);
				String message = null;
				if(s.equalsIgnoreCase(VOICES.get(0)) || s.equalsIgnoreCase(VOICES.get(1))) {
					message = "Command:t";
				}
				else if (s.equalsIgnoreCase(VOICES.get(2)) || s.equalsIgnoreCase(VOICES.get(3))) {
					message = "Command:y";
				}
				Log.d(TAG, "send question " + message);

				try {
					communicator.send(message);
					Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			else {
				Toast.makeText(this, s + " - nepodporovany prikaz", Toast.LENGTH_SHORT).show();

			}
		}		
	}
	
	public static boolean containsVoiceComand(String com) {
		if(VOICES == null) 
			addStringsToList();
		
		if(VOICES != null){
			for(String s : VOICES){
				if(s.equalsIgnoreCase(com))
					return true;
			}
		}
		return false;
	}
	
	@Override
	protected void onResume() {
//		communicator.registerOnServerResponseListener(this);
		super.onResume();
	}
	
	@Override
	protected void onPause() {
//		communicator.unregisterOnServerResponseListener();
		super.onPause();
	}

	
	@Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.activity_voice_recognition, menu);
        return true;
    }    
    
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
    	Intent intent;
    	switch (item.getItemId()) {
		case R.id.voices_list:
			intent = new Intent(this, VoiceCommandsListActivity.class);
			startActivity(intent);
			break;
		}
    	return true;
    }
}