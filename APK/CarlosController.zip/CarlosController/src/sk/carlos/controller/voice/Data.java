package sk.carlos.controller.voice;



import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;

import sk.carlos.controller.helper.*;;

public class Data {
	
	private static List<String> VOICES = null;
	
	public static List<String> getVoices(){
		return VOICES;
	}
	
	public static int getVoicesCount(){
		return (VOICES == null) ? 0 : VOICES.size();
	}
	
	public static void addVoice(String command){
		if(VOICES == null)
			VOICES = new ArrayList<String>();
		VOICES.add(command);
		backupVoices();
	}
	
	public static void removeVoice(String voice){
		if(VOICES != null && voice != null && voice.length() > 0){
			for(int i = 0; i < VOICES.size(); i++){
				if(voice.equalsIgnoreCase(VOICES.get(i))){
					VOICES.remove(i);
					backupVoices();
					return;
				}					
			}
		}
	}
	
	@SuppressWarnings("unchecked")
	public static void loadVoices(){
		try {
			VOICES = null;
			InputStream input = new FileInputStream(FileHelper.getDefaultVoices());
			ObjectInputStream inputObjects = new ObjectInputStream(input);
			VOICES = (List<String>) inputObjects.readObject();
			inputObjects.close();
			input.close();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public static void backupVoices(){
		try {
			if(VOICES == null) return;
			FileOutputStream output = new FileOutputStream(FileHelper.getDefaultVoices());
			ObjectOutputStream outputObject = new ObjectOutputStream(output);
			outputObject.writeObject(VOICES);
			outputObject.close();
			output.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static boolean containsVoiceComand(String com) {
		if(VOICES == null) loadVoices();
		if(VOICES != null){
			for(String s : VOICES){
				if(s.equalsIgnoreCase(com))
					return true;
			}
		}
		return false;
	}
}
