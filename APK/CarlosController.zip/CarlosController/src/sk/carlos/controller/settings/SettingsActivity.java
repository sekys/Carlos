package sk.carlos.controller.settings;

import java.io.File;
import java.io.FileOutputStream;
import java.io.PrintStream;
import java.util.Calendar;
import java.util.Timer;

import sk.carlos.controller.R;
import sk.carlos.controller.helper.*;
import sk.carlos.controller.server.*;

import android.app.Activity;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnKeyListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.TextView.OnEditorActionListener;

public class SettingsActivity extends Activity implements OnClickListener{
	
	private EditText ipSetter;
	private Button saver;
	
	FileOutputStream out;
	PrintStream printStream;

	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.settings_activity_layout);
		getActionBar().setIcon(R.drawable.ic_bulb);
        getActionBar().setBackgroundDrawable(getResources().getDrawable(R.drawable.action_bar_bg));
		ipSetter = (EditText) findViewById(R.id.ip_setter);
		saver = (Button) findViewById(R.id.save_button);
		saver.setOnClickListener(this);
		ipSetter.setText(PreferenceHelper.getServerIp(this));
	}

	@Override
	public void onClick(View v) {
		
		String root = Environment.getExternalStorageDirectory().toString();
		  File myDir = new File(root);    
		  myDir.mkdirs();
		  		  
		  
	      /** @file ipadress.txt
	       * file contains ip address an port
	       */
		  String fname = "ipaddress.txt";
		  File file = new File (myDir, fname);
		  
		  if (file.exists ()) file.delete (); 
		  try {
		         out = new FileOutputStream(file);
		         printStream = new PrintStream(out);
		  } catch (Exception e) {
		         e.printStackTrace();
		  }
		  
		if(StringHelper.isIPCorrect(ipSetter.getText().toString())){
			Log.d("Setting activity", "IP adresa: " + ipSetter.getText().toString());
			printStream.print(ipSetter.getText().toString());
			
			
			PreferenceHelper.setServerIp(this, ipSetter.getText().toString());	
//			if(SocketClient.getInstance() != null) 
////				SocketClient.getInstance().finish(true);
//			
//			SocketClient.createInstance(ipSetter.getText().toString(), this);
			
			finish();
		}else{
			ipSetter.setText("");
			ipSetter.setError(getString(R.string.server_url_invalid));
		}
	}
}
