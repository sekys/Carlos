package sk.carlos.controller.settings;

import sk.carlos.controller.R;
import sk.carlos.controller.helper.*;
import android.app.Activity;
import android.os.Bundle;
import android.view.KeyEvent;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class WebSettingsActivity extends Activity {

	private WebView web;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.web_settings_activity_layout);
		getActionBar().setIcon(R.drawable.ic_bulb);
        getActionBar().setBackgroundDrawable(getResources().getDrawable(R.drawable.action_bar_bg));
		this.web = (WebView) findViewById(R.id.web_view);
		this.web.setWebViewClient(webViewClient);
		this.web.getSettings().setJavaScriptEnabled(true);
		web.loadUrl(PreferenceHelper.getServerIp(this));
	}

	private static WebViewClient webViewClient = new WebViewClient() {
		@Override
		public boolean shouldOverrideUrlLoading(WebView view, String url) {
			view.loadUrl(url);
			return true;
		}
	};

	public void onBackPressed() {
		if (this.web.canGoBack()) {
			this.web.goBack();
			return;
		} else
			super.onBackPressed();
	}
}
