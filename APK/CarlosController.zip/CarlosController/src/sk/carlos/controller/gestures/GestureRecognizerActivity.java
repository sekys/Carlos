package sk.carlos.controller.gestures;

/*
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

import sk.carlos.controller.R;
import sk.carlos.controller.server.Comunnicator;


import android.app.Activity;
import android.content.Intent;
import android.gesture.Gesture;
import android.gesture.GestureLibraries;
import android.gesture.GestureLibrary;
import android.gesture.GestureOverlayView;
import android.gesture.GestureOverlayView.OnGesturePerformedListener;
import android.gesture.GestureStore;
import android.gesture.Prediction;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

public class GestureRecognizerActivity extends Activity implements OnGesturePerformedListener, OnServerResponseListener {
	
	private static final String TAG = "Controller - " + GestureRecognizerActivity.class.getSimpleName();
	private static final double GESTURE_TRESHOLD = 2.0d;
	
	private GestureOverlayView gestureOverlay;
	
	private  Comunnicator communicator;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.recognizer_layout);
		getActionBar().setIcon(R.drawable.ic_bulb);
        getActionBar().setBackgroundDrawable(getResources().getDrawable(R.drawable.action_bar_bg));
		gestureOverlay = (GestureOverlayView) findViewById(R.id.gestures_overlay);
		gestureOverlay.addOnGesturePerformedListener(this);
		try {
			if (communicator.getInstance() == null)
				communicator = communicator.createInstance(this);
			else
				communicator = communicator.getInstance();
		} catch (NullPointerException e) {
			Log.d(TAG, "exception by creating server communication instance ",e);

		}
		//TODO get gestures from file or smth
//		FileHelper.getGestureLibrary().load();
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.activity_gestures, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		Intent activity;
		switch (item.getItemId()) {
		case R.id.gestures_add:
			 activity = new Intent(this, GestureRecognizerActivity.class);
			startActivity(activity);
			break;
		case R.id.gestures_all:
			activity = new Intent(this, GestureRecognizerActivity.class);
			startActivity(activity);
			break;
		case R.id.web_settings:
//			activity = new Intent(this, WebSettingsActivity.class);
			startActivity(activity);
			break;
		default:
			break;
		}
		return true;
	}

	@Override
	public void onGesturePerformed(GestureOverlayView overlay, Gesture gesture) {
		ArrayList<Prediction> predictions = FileHelper.getGestureLibrary().recognize(gesture);
		Collections.sort(predictions, COMPARATOR);		
		Log.d(TAG, "count of predictions: "+ predictions.size());
		if(predictions.size() > 0){
			Prediction p = predictions.get(0);
			if(p.score > GESTURE_TRESHOLD){
				Log.d(TAG, "prediction score: " + p.score);
				Toast.makeText(this, p.name, Toast.LENGTH_SHORT).show();
				communicator.sendEvent(p.name);
			}		
		}	
	}
	
	private static Comparator<Prediction> COMPARATOR = new Comparator<Prediction>() {

		@Override
		public int compare(Prediction p1, Prediction p2) {
			if(p1.score > p2.score) return -1;
			else if(p1.score == p2.score) return 0;
			else return 1;
		}
	};
	
	@Override
	protected void onResume() {
//		communicator.registerOnServerResponseListener(this);
		super.onResume();
	}
	
	@Override
	protected void onPause() {
//		communicator.unregisterOnServerResponseListener();
		super.onPause();
	}
}
*/
