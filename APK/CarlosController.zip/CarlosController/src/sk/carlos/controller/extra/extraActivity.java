package sk.carlos.controller.extra;

import java.io.IOException;

import sk.carlos.controller.R;
import sk.carlos.controller.move.MoveActivity;
import sk.carlos.controller.server.*;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class extraActivity extends Activity implements OnClickListener {

	private static final String TAG = "Controller - " + extraActivity.class.getSimpleName();

	private Comunnicator communicator;
	
	private Button button_up;
	private Button button_down;
	private Button button_left;
	private Button button_right;
	private Button button_one;
	private Button button_two;
	private Button button_three;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.extra_activity_layout);
		getActionBar().setIcon(R.drawable.ic_bulb);
		getActionBar().setBackgroundDrawable(getResources().getDrawable(R.drawable.action_bar_bg));

		try {
			if (communicator.getInstance() == null)
				communicator = communicator.createInstance(this);
			else
				communicator = communicator.getInstance();
		} catch (NullPointerException e) {
			Log.d(TAG, "exception by creating server communication instance ",e);
		}
		
		button_up = (Button) findViewById(R.id.button_up);
		button_down = (Button) findViewById(R.id.button_down);
		button_left = (Button) findViewById(R.id.button_left);
		button_right = (Button) findViewById(R.id.button_right);
		button_one = (Button) findViewById(R.id.button_one);
		button_two = (Button) findViewById(R.id.button_two);
		button_three = (Button) findViewById(R.id.button_three);
		
		button_up.setOnClickListener(this);
		button_down.setOnClickListener(this);
		button_left.setOnClickListener(this);
		button_right.setOnClickListener(this);
		button_one.setOnClickListener(this);
		button_two.setOnClickListener(this);
		button_three.setOnClickListener(this);
		
	}

	@Override
	protected void onPause() {
		// TODO Auto-generated method stub
		super.onPause();
	}

	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
	}

	@Override
	public void onClick(View v) {
		String msg = "null";
		switch (v.getId()) {
		case R.id.button_up:
			msg = "Command:w";
			break;
		case R.id.button_down:
			msg = "Command:s";
			break;
		case R.id.button_left:
			msg = "Command:a";
			break;
		case R.id.button_right:
			msg = "Command:d";
			break;
		case R.id.button_one:
			msg = "one";
			break;
		case R.id.button_two:
			msg = "two";
			break;
		case R.id.button_three:
			msg = "three";
			break;
		default:
			break;
		}
		try {
			Log.d(TAG, "Send event: " + msg);
			communicator.send(msg);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

	
	
}
