package sk.carlos.controller.gps;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.util.Calendar;
import java.util.Timer;
import java.util.TimerTask;

import sk.carlos.controller.R;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

// Location Listener 
@SuppressLint("HandlerLeak")
public class gpsLoggerActivity extends Activity implements LocationListener{
	
	  private TextView latituteField;
	  private TextView longitudeField;
	  private Button start_button;
	  private Button stop_button;
	  
	  TextView labelTimer;
	  
	  private LocationManager locationManager;
	  private String provider;
	  Location location;
	  double lat;
	  double lon;
	  boolean running_flag = false;
	  boolean write_to_file = false;
	  
	  Timer timer;
	  TimerTask timerTask;
	  int passedSenconds;

	  FileOutputStream out;
	  PrintStream printStream;
	  
	  Calendar rigthNow;
	  
	   
	  @Override
	  public void onCreate(Bundle savedInstanceState) {
	    super.onCreate(savedInstanceState);
	    setContentView(R.layout.gps_logger_layout);
		getActionBar().setIcon(R.drawable.ic_bulb);
		getActionBar().setBackgroundDrawable(getResources().getDrawable(R.drawable.action_bar_bg));

	    
	    latituteField = (TextView) findViewById(R.id.latitude_values_textView);
	    longitudeField = (TextView) findViewById(R.id.longitude_values_textView);
	    
	    // Buttons
	    start_button = (Button) findViewById(R.id.button_GPSstart);
	    stop_button = (Button) findViewById(R.id.button_GPSstop);
	  
	    labelTimer = (TextView)findViewById(R.id.labelTime);
	    
	    // Make then unvisible
	    start_button.setEnabled(false);
	    stop_button.setEnabled(false);

	    // Get the location manager
	    locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);

	    // Some criteria 
	    Criteria criteria = new Criteria();
	    provider = locationManager.getBestProvider(criteria, false);
	    location = locationManager.getLastKnownLocation(provider);

	    // Initialize the location fields
	    if (location != null) {
	      System.out.println("Provider " + provider + " has been selected.");
	      onLocationChanged(location);
	    } else {
	      latituteField.setText("Location not available");
	      longitudeField.setText("Location not available");
	    }
	  }
	  
	  /**
	   *  Request updates at startup 
	   *  */
	  @Override
	  protected void onResume() {
	    super.onResume();
	    locationManager.requestLocationUpdates(provider, 400, 0, this);
	  }

	  /**
	   *  Remove the locationlistener updates when Activity is paused 
	   *  */
	  @Override
	  protected void onPause() {
	    super.onPause();
	    locationManager.removeUpdates(this);
	  }

	  
	  @Override
	  public void onLocationChanged(Location location) {
	    lat = location.getLatitude();
	    lon = location.getLongitude();
	    
	    //System.out.println(String.valueOf(lat) + ", " + String.valueOf(lng) + ", ");
	    
	    latituteField.setText(String.valueOf(lat));
	    longitudeField.setText(String.valueOf(lon));
	    // We can be ready for start :)
	    if (running_flag == false)
	    	start_button.setEnabled(true);
	    
	    /*if (running_flag == true)
	    {
	    	Toast.makeText(this, "I'm running bitch",
	    	        Toast.LENGTH_SHORT).show();
	    }*/
	    
	  }  

	  @Override
	  public void onStatusChanged(String provider, int status, Bundle extras) {
	    // TODO Auto-generated method stub

	  }

	  @Override
	  public void onProviderEnabled(String provider) {
	    Toast.makeText(this, "Enabled new provider " + provider,
	        Toast.LENGTH_SHORT).show();

	  }

	  @Override
	  public void onProviderDisabled(String provider) {
	    Toast.makeText(this, "Disabled provider " + provider,
	        Toast.LENGTH_SHORT).show();
	  }
	  
	  public void start_method (View view)
	  {
		  start_button.setEnabled(false);
		  stop_button.setEnabled(true);
		  running_flag = true;
		
		  // Start the timer 
		  reScheduleTimer();		  
		  
	  }
	  
	  public void stop_method (View view) throws IOException
	  {		  
		  passedSenconds = 0;
		  running_flag = false;
		  timer.cancel();
		  
		  printStream.close();
	         
	      out.flush();
	      out.close();
		  
		  stop_button.setEnabled(false);
		  start_button.setEnabled(true);
		  labelTimer.setText(String.format("00 : 00 : 00"));
		  
		  running_flag = false;
	  }
	  
	  
	  public void reScheduleTimer(){
		  
		//Create file 
		  String root = Environment.getExternalStorageDirectory().toString();
		  File myDir = new File(root);    
		  myDir.mkdirs();
		  
		  
		  // GET TIME INFORMATION FOR FILE
		  rigthNow = Calendar.getInstance();
	    	
	      int hour = rigthNow.get(Calendar.HOUR_OF_DAY); /** < variable for hour value */
	      int minute = rigthNow.get(Calendar.MINUTE);  /** < variable for minute value */
	      int day = rigthNow.get(Calendar.DATE); /** < variable for day value */
	      int month = rigthNow.get(Calendar.MONTH)+1; /** < variable for month value */  // I have to have there +1 because 
	      int year = rigthNow.get(Calendar.YEAR);  /** < variable for year value */
	      int seconds = rigthNow.get(Calendar.SECOND); /** < variable for seconds value */
	    	
	      
	      String time = year + "-" + month + "-" + day + "-" + hour + "-" + minute + "-" + seconds; /** < variable for final time value */  
		  
		 
	      /** @file time.txt
	       * file contains 3 columns - latitude | longitude | timestamp
	       */
		  String fname = time +".txt";
		  File file = new File (myDir, fname);
		  if (file.exists ()) file.delete (); 
		  try {
		         out = new FileOutputStream(file);
		         printStream = new PrintStream(out);

		  } catch (Exception e) {
		         e.printStackTrace();
		  }
		  
	        timer = new Timer();
	        timerTask = new myTimerTask();
	        timer.schedule(timerTask, 0, 1000);
	    }
	  
	  private class myTimerTask extends TimerTask{
	        @Override
	        public void run() {
	            // TODO Auto-generated method stub
	            passedSenconds++;
	            updateLabel.sendEmptyMessage(0);
	           // double lat = location.getLatitude();
	    	   // double lng = location.getLongitude();
	        }
	    }
	  
	  
	  private Handler updateLabel = new Handler(){
	        @Override
	        public void handleMessage(Message msg) {
	            // TODO Auto-generated method stub
	            //super.handleMessage(msg);

	            int secondss = passedSenconds % 60;
	            int minutes = (passedSenconds / 60) % 60;
	            int hours = (passedSenconds / 3600);
	            
	            // We will nicely show the time BITCH
	            labelTimer.setText(String.format("%02d : %02d : %02d", hours, minutes, secondss));
	            
	            rigthNow = Calendar.getInstance();
		    	
		    	System.out.println(String.valueOf(lat) + ", " + String.valueOf(lon) + ", ");
		    	
		    	int hour = rigthNow.get(Calendar.HOUR_OF_DAY);
			    int minute = rigthNow.get(Calendar.MINUTE);
			    int day = rigthNow.get(Calendar.DATE);
			    int month = rigthNow.get(Calendar.MONTH)+1; // I have to have there +1
			    int year = rigthNow.get(Calendar.YEAR);
			    int seconds = rigthNow.get(Calendar.SECOND);
			    	
			    String time = year + "-" + month + "-" + day + "-" + hour + "-" + minute + "-" + seconds;
			      
		    	printStream.print(String.valueOf(lat) + ", " + String.valueOf(lon) + ", " + time + "\n" );
		         
	        }
	    }; 
}
