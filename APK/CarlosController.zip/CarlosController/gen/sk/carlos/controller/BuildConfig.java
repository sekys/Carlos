/** Automatically generated file. DO NOT MODIFY */
package sk.carlos.controller;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}